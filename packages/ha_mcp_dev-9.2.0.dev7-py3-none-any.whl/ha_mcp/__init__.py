"""
Home Assistant MCP Server

A Model Context Protocol server that provides complete control over Home Assistant
through REST API and WebSocket integration.
"""

# Must be imported before anything that reaches fastmcp (``.auth`` below does),
# because fastmcp configures rich logging at import time and dies on a rich
# older than 13.9.4. Importing this module applies the shim. See #2186.
from . import _rich_compat as _rich_compat
from ._version import get_version

__version__ = get_version()
__author__ = "Julien"
__license__ = "MIT"

from .auth import HomeAssistantOAuthProvider
from .client.rest_client import HomeAssistantClient
from .config import Settings
from .errors import (
    ErrorCode,
    create_auth_error,
    create_config_error,
    create_connection_error,
    create_entity_not_found_error,
    create_entity_unavailable_after_dispatch_error,
    create_error_response,
    create_service_error,
    create_timeout_error,
    create_validation_error,
    get_error_code,
    get_error_message,
    is_error_response,
)
from .server import HomeAssistantSmartMCPServer

__all__ = [
    "Settings",
    "HomeAssistantClient",
    "HomeAssistantSmartMCPServer",
    "HomeAssistantOAuthProvider",
    # Error handling exports
    "ErrorCode",
    "create_error_response",
    "create_connection_error",
    "create_auth_error",
    "create_entity_not_found_error",
    "create_entity_unavailable_after_dispatch_error",
    "create_service_error",
    "create_validation_error",
    "create_config_error",
    "create_timeout_error",
    "is_error_response",
    "get_error_code",
    "get_error_message",
]
